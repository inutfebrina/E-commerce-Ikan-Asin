<?php
	session_start();

	require "./includes/koneksi.php";
	require "./includes/lib.php";
	require "./includes/fungsi.php";
	require "./includes/title.php";
	require "./includes/header.php";
	require "./includes/visitor.php";
	require "./module/rss.php";

	require "".ft."index.php";
	require "./includes/seo.php";


?> 