<?php
session_start();

	if(!isset($_SESSION['id_user']) && !isset($_SESSION['username'])){
			  header('location:login.php');
	}

	//fungsi pagination
    $BatasAwal = 15;
    if (!empty($_GET['p'])) {
        $hal = $_GET['p'] - 1;
        $MulaiAwal = $BatasAwal * $hal;
    } else if (!empty($_GET['p']) and $_GET['p'] == 1) {
        $MulaiAwal = 0;
    } else if (empty($_GET['p'])) {
        $MulaiAwal = 0;
    }
	
?>
<style type="text/css">
	.tabel {
		color: #FFF;

	}

	a{
		text-decoration:none;
	}

	a:hover{
		opacity:0.8;
		text-decoration:underline;
	}
</style>
	
<div class="path"><h3>LAPORAN</h3></div>
  <br>


<form action="..\admin\module\laporan\cari.php" method="post" name="postform">
            <p align="center"><font color="000" size="3"><b>Laporan Penjualan</b></font></p><br />
            <table border="0">
                <tr>
                    <td width="125"><b>Dari Tanggal</b></td>
                    <td colspan="2" width="190">: <input type="date" name="tanggal_awal" size="16" />
                                
                    </td>
                    <td width="125"><b>Sampai Tanggal</b></td>
                    <td colspan="2" width="190">: <input type="date" name="tanggal_akhir" size="16" />
                   
                    </td>
                    <td colspan="2" width="190"><input type="submit" value="Cetak" name="pencarian"/></td>

                </tr>
            </table>
        </form>