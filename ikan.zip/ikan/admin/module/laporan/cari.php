 <?php
            $Open = mysql_connect("localhost","root","");
                if (!$Open){
                die ("Koneksi ke Engine MySQL Gagal !");
                }
            $Koneksi = mysql_select_db("ikan");
                if (!$Koneksi){
                die ("Koneksi ke Database Gagal !");
                }
        ?>
		<?php
            //proses jika sudah klik tombol pencarian data
            if(isset($_POST['pencarian'])){
            //menangkap nilai form
            $tanggal_awal=$_POST['tanggal_awal'];
            $tanggal_akhir=$_POST['tanggal_akhir'];
            if(empty($tanggal_awal) || empty($tanggal_akhir)){
            //jika data tanggal kosong
            ?>
            <script language="JavaScript">
                alert('Tanggal Awal dan Tanggal Akhir Harap di Isi!');
                document.location='index.php';
            </script>
            <?php
            }else{
            ?><i><b>Laporan Tanggal <b><?php echo $_POST['tanggal_awal']?></b> s/d <b><?php echo $_POST['tanggal_akhir']?></b></i>
            <?php
          //  $query=mysql_query("select * from t_tagihan where tgl_tagihan between '$tanggal_awal' and '$tanggal_akhir'");
			$query=mysql_query("select *from t_tagihan INNER JOIN t_member on (t_tagihan.id_member=t_member.id_member) where tgl_tagihan between '$tanggal_awal' and '$tanggal_akhir'");
            }
        ?>
        </p>
        <table width="1100" border="1" align="center" cellpadding="0" cellspacing="0">
            <tr >
            <th width="50" scope="col" bgcolor='#fff'>NO</th>
            <th width="100" scope="col" bgcolor='#fff'>No. Order</th>
    		<th width="114" height="48" align="center" bgcolor="#fff" scope="col">Nama</th>
    		<th width="132" bgcolor="#fff" scope="col">Tgl Order</th>
            <th width="132" bgcolor="#fff" scope="col">Total</th>
   			<th width="114" bgcolor="#fff" scope="col">Status</th>   
            </tr>
            <?php
            //menampilkan pencarian data
			$no = 1;
            while($row=mysql_fetch_array($query)){
            ?>
            <tr>
            	<td align="center" height="30"><?php echo $no; ?></td>
                <td align="center" height="30"><?php echo $row['id_tagihan']; ?></td>
                <td align="center"><?php echo $row['nama_lengkap']; ?></td>
                <td align="center"><?php echo $row['tgl_tagihan'];?></td>
                <td align="center"><?php echo $row['total_tagihan'];?></td>
                <td align="center"><?php echo $row['status_tagihan'];?></td>
                           </tr>
            <?php
			$no++;
            }
            ?>   
     
            <tr>
                <td colspan="5" align="center"> 
                <?php
                //jika pencarian data tidak ditemukan
                if(mysql_num_rows($query)==0){
                    echo "<font color=red><blink>Data tidak ditemukan!</blink></font>";
                }
                ?>
                </td>
            </tr> 
        </table>
        <?php
        }
        else{
            unset($_POST['pencarian']);
        }
        ?>
		        
        
      
      
<script>
window.print();
</script>