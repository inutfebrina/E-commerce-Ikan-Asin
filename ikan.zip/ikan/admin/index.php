<?php 

	session_start();

	if(!isset($_SESSION['id_user']) && !isset($_SESSION['username'])){
		header('location:login.php');
	}

	$awalload = microtime(true);

	require_once "../includes/koneksi.php";
	require_once "../includes/lib.php";
	require_once "../includes/fungsi.php";
	

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo "".$judul_web." - Halaman Login "; ?></title>
<link rel='SHORTCUT ICON' href='<?php echo ".".$favicon_web.""; ?>'>

<script src="js/jquery.min.js"></script>
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<script src="js/SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="js/SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<script src="js/SpryAssets/SpryValidationTextarea.js" type="text/javascript"></script>
<script src="js/js.js" type="text/javascript"></script>
<link href="js/SpryAssets/SpryValidationTextarea.css" rel="stylesheet" type="text/css" />
<script src="plugins/ckeditor/ckeditor.js" type="text/javascript"></script>

<link rel="stylesheet" href="js/fancybox/jquery.fancybox.css?v=2.1.5" type="text/css" media="screen" />
<script type="text/javascript" src="js/fancybox/jquery.fancybox.pack.js?v=2.1.5"></script>

<style type="text/css">
<!--
.style1 {color: #00ACA2}
-->
</style>
</head>

<body>

<div class="banner"></div>



<div class="konten">
	<div class="side-menu">
		<div class="menu-header">
			<h2 class="style1">MENU ADMIN </h2>
	  </div>

<div id="wrapper">
		<ul class="menu">
			<li><a href="index.php?module=dashboard" ><i class="fa fa-home"></i> Home</a></li>
			<li><a href="#"><i class="fa fa-edit"></i>  Kelola<span><i class='fa fa-caret-down'></i></span></a>
				<ul>
					<li><a href="index.php?module=kategori">Kategori</a></li>
					<li><a href="index.php?module=produk">Produk</a></li>
				</ul>
			</li>
			<li><a href="#"><i class="fa fa-bars"></i>  Pesanan<span><i class='fa fa-caret-down'></i></span></a>
				<ul>
					<li><a href="index.php?module=order">Daftar Pesanan</a></li>
					<li><a href="index.php?module=laporan">Laporan</a></li>
					<li> <a href="index.php?module=konfirmasi">Konfirmasi Pembayaran</a></li>
				</ul>
			</li>
			<li><a href="index.php?module=member"><i class="fa fa-users"></i>  Member</a></li>
			<li><a href="index.php?module=testimonial"><i class="fa fa-quote-right"></i> Testimonial</a></li>
            <li><a href="index.php?module=pesan"><i class="fa fa-envelope"></i> Chat</a></li>
             <li><a href="index.php?module=shipping"><i class="fa fa-caret-down"></i>  Pengiriman</a></li>						
			<li><a href="#"><i class="fa fa-info-circle"></i>  Pengaturan<span><i class='fa fa-caret-down'></i></span></span></a>
				<ul>

					<li><a href="index.php?module=tentang">Tentang Kami</a></li>
					<li><a href='index.php?module=rekening'>Rekening</a></li>
				</ul>

			
			
			</li>
				<li><a href="index.php?module=keluar"><i class="fa fa-power-off"></i>  Keluar</a></li>
			</ul>
	</div>
</div>

	<div class="isi">
<?php
	if($module=='kategori'){	
		if($aksi=='kelola' || $aksi=='hapus'){
			include "module/kategori/k-kategori.php";
		}else{
			include "module/kategori/kategori.php";
		}
	}elseif($module=='produk'){
		if($aksi=='kelola' || $aksi=='hapus'){
			include "module/produk/k-produk.php";
		}else{
			include "module/produk/produk.php";
		}		
	}elseif($module=='order'){
		if($aksi=='kelola'){
			include 'module/order/k-order.php';
		}elseif($id!=''){
			include 'module/order/detail.php';
		}else{
			include "module/order/order.php";
		}
	}elseif($module=='konfirmasi'){
			include 'module/konfirmasi/konfirmasi.php';
	}elseif($module=='laporan'){
			include 'module/laporan/laporan.php';
						
	
	}elseif($module=='rekening'){
		if($aksi=='kelola' || $aksi=='hapus'){
			include 'module/rekening/k-rekening.php';
		}else{
			include 'module/rekening/rekening.php';
		}
	}elseif($module=='tentang'){
			include 'module/profil/tentang.php';
	
	}elseif($module=='kontak'){
			include 'module/kontak/kontak.php';
	}elseif($module=='sosmed'){
			include 'module/kontak/sosmed.php';
	}elseif($module=='profil'){
		if($aksi=='kelola'){
			include 'module/profil/k-profil.php';
		}else{
			include 'module/profil/profil.php';
		}
	}elseif($module=='testimonial'){
			include 'module/testimonial/testimonial.php';
		
	}elseif($module=='shipping'){
		if($aksi=='kelola' || $aksi=='hapus'){
			include 'module/ongkir/k-shipping.php';
		}else{
			include "module/ongkir/shipping.php";
		}
	}elseif($module=='member'){
		if(isset($id)){
			include "module/member/detail.php";
		}else{
			include "module/member/member.php";
		}
	
	}elseif($module=='pengaturan' && $level=='super admin'){
		include "module/pengaturan/pengaturan.php";
	}elseif($module=='pesan'){
		if($aksi=='kirim'){
				include "module/pesan/kirim-pesan.php";
			}else{
				include "module/pesan/kotak-pesan.php";
		}
	}elseif($module=='keluar'){
		$sql_user=mysql_query("update t_user SET ip_login='".$_SERVER['REMOTE_ADDR']."',last_login='".date("d-m-Y H:i")."' where id_user=".$_SESSION['id_user'].""); 
		session_destroy();
		session_unset();
		echo "<script>window.location=('login.php');</script>";
	}else{
		include "module/dashboard/dashboard.php";
	}
?>

	</div>
		<br><br>
</div>
<br>

<center>
	<font style="color:#888888"><?php echo "".$judul_web.""; $akhirload = microtime(true); $waktuload = $akhirload  - $awalload; ?> - Powered by vMart - Version  <?php  echo "".versi_cms." - Page Load : " . number_format($waktuload, 3, '.', '') . " s"; ?></center>
	<br>
</div>

</body>
</html>

<script>	  
	$(document).ready(function() {
		$("#single_1").fancybox({
			  helpers: {
				  title : {
					  type : 'float'
				  }
			  }
		  });

	});
 </script> 
<script type="text/javascript">
	$(function() {
	
	    var menu_ul = $('.menu > li > ul'),
	           menu_a  = $('.menu > li > a');
	    
	    menu_ul.hide();
	
	    menu_a.click(function(e) {
	        
	        if(!$(this).hasClass('active')) {
	            menu_a.removeClass('active');
	            menu_ul.filter(':visible').slideUp('normal');
	            $(this).addClass('active').next().stop(true,true).slideDown('normal');
	        } else {
	            $(this).removeClass('active');
	            $(this).next().stop(true,true).slideUp('normal');
	        }
	    });
	
	});
</script>
 


