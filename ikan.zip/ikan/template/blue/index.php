<?php

// FT = Folder Template //

	echo '
	
<link href="'.ft.'css/style.css" rel="stylesheet" type="text/css" />
<link href="'.ft.'css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="'.ft.'css/fancybox/jquery.fancybox.css?v=2.1.5" type="text/css" media="screen" />

<script src="'.ft.'js/craftyslide/jquery.js"></script>
<script src="'.ft.'js/jquery.min.js"></script>
<link rel="stylesheet" href="'.ft.'css/craftyslide.css" />
<script src="'.ft.'js/SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="'.ft.'js/SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<link href="'.ft.'js/SpryAssets/SpryValidationTextarea.css" rel="stylesheet" type="text/css">
<script src="'.ft.'js/SpryAssets/SpryValidationTextarea.js" type="text/javascript"></script>
<script src="'.ft.'js/newsticker.js" type="text/javascript"></script>
<script type="text/javascript" src="'.ft.'css/fancybox/jquery.fancybox.pack.js?v=2.1.5"></script>
<script type="text/javascript" src="'.ft.'js/js.js"></script>

	'
?>

</head>

<body>
<div class="konten-isi">

<div class="menu-header">
	<ul>


		<li><a href="index.php?module=tentang">Tentang Kami</a></li>

	<ul>
		<li><?php echo "".$hari." ".$tgl." ".$bulan." ".$thn." "; // Menampilkan Tanggal // ?></li>
	</ul>
</ul>
</div>

<div class="header">
	
</div>

<div class="menu-user">
	<span>Selamat Datang di <?php echo "".ubah_huruf_awal(" ",$judul_web)."" ?></span>

	<ul>
		<?php
			require "".ft."menu.php";
			
		?>
	
	</ul>
</div>



<div class="left-bar">
	<div class="kategori">
		<div class="judul-kategori">Kategori</div>
			<ul><?php 
			  $sql_kategori=mysql_query("select *from t_kategori");
			  while($row_kategori=mysql_fetch_assoc($sql_kategori))
				{
					echo "<li><a href='index.php?module=produk&kategori=".$row_kategori['id_kategori']."'>".$row_kategori['nama_kategori']."</a><br></li>";
				}?> 
			</ul>
		</div>
	</div>


<div class="cari">
	<form id="form1" name="form1" method="post" action="index.php?module=cari">
		<input name="search" type="text" id="search" size="71px" placeholder="Cari Produk"/>
		<input type="submit" name="btn-search" id="btn-search" class="button blue" style="height:30px;padding-top:5px;width:50px" value="Cari" />
	</form>
</div>

<div class="tempat-konten">
	<?php
		include "".folder_inc."tengah.php";
	?>
</div>
<div class="kanan-bar">

<!-- Keranjang -->
<div class="keranjang">
	<div class="judul-kanan">Keranjang Belanja</div>
	<br><i class="fa fa-shopping-cart" style="margin-left:10px;"></i>
	<?php

		// Widget Keranjang Belanja //
		
	if(isset($id_member)){
		$check_ker=mysql_num_rows(mysql_query("select *from t_keranjang where id_member=".$id_member."")); // Hitung Jumlah Barang di Keranjang //
		if(!isset($check_ker)){ $check_ker=0; };
			echo "<font color='#441114' style='text-weight:bold'>".$check_ker."</font> item produk ";
		if($check_ker>0){
			echo "<a href='index.php?module=cart' target='_blank' style='text-decoration:none;color:#7F262D;'> <h5>> Lihat Keranjang</h5></a>
				  <a href='index.php?module=check-out' target='_blank' style='text-decoration:none;color:#7F262D;'> <h5 style='margin-top:-20px;'>> Selesai Belanja</h5></a>";
		}
	}else{
		echo "<font color='#441114' style='text-weight:bold'>0</font> item produk ";
	}
?>
</div>
<!-- -->

<!-- Pembayaran -->
	<div class="pembayaran">
		<div class="judul-kanan">Bank Pembayaran</div>
		<?php 
			$sql_rek=mysql_query("select *from t_rekening");
			while($row_rek=mysql_fetch_assoc($sql_rek)){
				echo "".logobank($row_rek['nama_bank'])."<br>
					  <span>Rek : ".$row_rek['no_rekening']."<br></span>
					  <span>A/N : ".$row_rek['nama_pemilik']."<br></span><hr>
					 ";
					 };
		?>
	</div>
<!-- -->


<!-- Visitor -->
<div class="visitor">
	<div class="judul-kanan">Statistik Pengunjung</div>
<?php echo "
		<b>Online :</b> ".$pengunjungonline." visit <br>
		<b>Hari ini :</b> ".$pengunjung." visit <br>
		<b>Kemarin : </b> ".$kemarin." visit<br>
		<b>Total :</b> ".$totalpengunjung." visit <br>
";
?>
	</div>
</div>
<!-- -->

<hr style="color:#DDDDDD; border-color:#DDDDDD; border-style:solid">

<center>
	<img src="<?php echo "".$lokasi_template."./images/shipping.png" ?>">
</center>



<div class="copyright">
<center>
Safrinaldi Santoso - <?php echo "".ubah_huruf_awal(" ",$judul_web).""; ?> 
</center>
</div>

</div>

</body>
</html>

<script src="<?php echo "".ft.""?>js/craftyslide/craftyslide.min.js"></script>

<script>
       $("#slideshow").craftyslide({
		'pagination': false,
		'fadetime': 500,
		'delay': 2500
});
</script> 
	  
<script>	  
$(document).ready(function() {
    $("#single_1").fancybox({
          helpers: {
              title : {
                  type : 'float'
              }
          }
      });

});
 </script> 