<?php
session_start();

	require "./module/cetak.php";
	
?>


<hr>
      <table width="560" cellpadding="0" cellspacing="1">
        <tr align="left">
          <td height="30" colspan="5" scope="col">&nbsp;Tagihan No : <?php echo $id ?><br>
       
          <br><br></td>
        </tr>
        <tr bgcolor="#575757" style="color:#FFFFFF">
          <th width="117" height="38">Produk</th>
          <th width="129">Harga</th>
          <th width="118">Qty</th>
          <th width="151">Jumlah</th>
        
        </tr>
<?php
	$sql_dorder=mysql_query("select *from t_order INNER JOIN t_produk on t_order.id_produk=t_produk.id_produk where id_tagihan=".$id."");
	$sql_dtag=mysql_query("select *from t_tagihan where id_tagihan=".$id."");
		$r=mysql_fetch_assoc($sql_dtag);
		
		$total_tagihan=$r['total_tagihan'];
		
	while($row_dtag=mysql_fetch_assoc($sql_dorder)){
	

	
		$nama_produk=$row_dtag['nama_produk'];
		$harga_produk=$row_dtag['harga_produk'];
		$qty=$row_dtag['qty'];
		$jumlah=$harga_produk*$qty;
		$jumlah_semua=$jumlah_semua+$jumlah;
		
	echo "
        <tr bgcolor='#F6F4F5' align='center'>
          <td height=30>".$nama_produk."</td>

          <td>".formatRupiah($harga_produk)."</td>
          <td>".$qty."</td>
          <td>".formatRupiah($jumlah)."</td>
      ";
	 }
	
	 $uang_kirim=$total_tagihan-$jumlah_semua;
	 
?>

        </tr>
        <tr  bgcolor="#E2EBEE">
          <th height="30" colspan="3" align="right">Biaya Pengiriman :&nbsp; </th>
          <th><?php echo formatRupiah($uang_kirim) ?></th>
   
        </tr>
        <tr  bgcolor="#B9FFFF">
          <th height="30" colspan="3" align="right" >Total :&nbsp;  </th>
          <th><?php echo formatRupiah($total_tagihan) ?></th>
     
        </tr>
      </table>
	    <br>
   </td>
  
  </tr>

</table>

</body>
</html>
<script>
window.print();
</script>