
  <div class="bread"><b style="font-weight:bold">- Tentang Kami</b></div>
<br>
<?php echo $tentang_web ?>
