-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 09, 2021 at 04:55 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ikan`
--

-- --------------------------------------------------------

--
-- Table structure for table `t_kategori`
--

CREATE TABLE IF NOT EXISTS `t_kategori` (
  `id_kategori` char(10) NOT NULL,
  `nama_kategori` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_kategori`
--

INSERT INTO `t_kategori` (`id_kategori`, `nama_kategori`) VALUES
('KT001', 'Ikan Asin');

-- --------------------------------------------------------

--
-- Table structure for table `t_keranjang`
--

CREATE TABLE IF NOT EXISTS `t_keranjang` (
`id_keranjang` int(10) NOT NULL,
  `id_member` int(10) NOT NULL,
  `id_produk` char(10) NOT NULL,
  `qty` int(5) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `t_member`
--

CREATE TABLE IF NOT EXISTS `t_member` (
`id_member` int(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(40) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `no_telp` varchar(20) NOT NULL,
  `alamat` varchar(300) NOT NULL,
  `provinsi` varchar(50) NOT NULL,
  `kota` varchar(50) NOT NULL,
  `kode_pos` int(10) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `t_member`
--

INSERT INTO `t_member` (`id_member`, `username`, `password`, `nama_lengkap`, `email`, `no_telp`, `alamat`, `provinsi`, `kota`, `kode_pos`) VALUES
(3, 'user', '085284fde346d0eb969d8dcd62b69b45', 'Safrinaldi Santoso', 'inutfebrina@gmail.com', '082387278635', 'Jalan Aru Indah no 14', 'Sumatera Barat', 'Padang', 25221);

-- --------------------------------------------------------

--
-- Table structure for table `t_order`
--

CREATE TABLE IF NOT EXISTS `t_order` (
`id_order` int(10) NOT NULL,
  `id_produk` varchar(10) NOT NULL,
  `id_member` int(10) NOT NULL,
  `id_tagihan` int(10) NOT NULL,
  `qty` int(10) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `t_pengaturan`
--

CREATE TABLE IF NOT EXISTS `t_pengaturan` (
  `id` int(1) NOT NULL,
  `judul_website` varchar(50) NOT NULL,
  `banner_website` varchar(50) NOT NULL,
  `favicon` varchar(50) NOT NULL,
  `keyword` varchar(100) NOT NULL,
  `deskripsi` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_pengaturan`
--

INSERT INTO `t_pengaturan` (`id`, `judul_website`, `banner_website`, `favicon`, `keyword`, `deskripsi`) VALUES
(1, 'E-Commerce Ikan Asin', './images/website/logo.png', './images/fav.ico', 'ikan asin', 'E-Commerce Pemasaran Ikan Asin ');

-- --------------------------------------------------------

--
-- Table structure for table `t_pesan`
--

CREATE TABLE IF NOT EXISTS `t_pesan` (
`id_pesan` int(3) NOT NULL,
  `tgl_pesan` date NOT NULL,
  `dari` varchar(20) NOT NULL,
  `untuk` varchar(20) NOT NULL,
  `judul_pesan` varchar(50) NOT NULL,
  `isi_pesan` varchar(200) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `t_pesan`
--

INSERT INTO `t_pesan` (`id_pesan`, `tgl_pesan`, `dari`, `untuk`, `judul_pesan`, `isi_pesan`) VALUES
(14, '2021-02-07', '3', 'Admin', 'nannya', 'ready gan?....'),
(15, '2021-02-07', 'Admin', '3', 'nanya', 'ready dong !'),
(16, '2021-02-07', '3', 'Admin', 'nanya', 'brapa kg?'),
(17, '2021-02-07', 'Admin', '3', 'sasa', '10 kg gan\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `t_produk`
--

CREATE TABLE IF NOT EXISTS `t_produk` (
  `id_produk` char(10) NOT NULL,
  `id_kategori` char(10) NOT NULL,
  `nama_produk` varchar(50) NOT NULL,
  `harga_produk` int(40) NOT NULL,
  `gambar_produk` varchar(30) NOT NULL,
  `deskripsi_produk` longtext NOT NULL,
  `berat` varchar(10) NOT NULL,
  `stok` enum('Masih','Habis') NOT NULL,
  `tgl_post` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_produk`
--

INSERT INTO `t_produk` (`id_produk`, `id_kategori`, `nama_produk`, `harga_produk`, `gambar_produk`, `deskripsi_produk`, `berat`, `stok`, `tgl_post`) VALUES
('KT001-1', 'KT001', 'Ikan Sibolga', 3500, './images/produk/KT001-1.jpeg', 'Harga Sekilo Ikan', '0.1', 'Masih', '2021-02-09'),
('KT001-10', 'KT001', 'Teri Jengki', 6500, './images/produk/KT001-10.jpg', 'Harga per Kilo', '0.1', 'Masih', '2021-02-09'),
('KT001-2', 'KT001', 'Ikan Asin Kase', 7000, './images/produk/KT001-2.jpg', 'Harga per Kilo', '0.1', 'Masih', '2021-02-09'),
('KT001-3', 'KT001', 'Cumi', 10000, './images/produk/KT001-2.jpg', 'Harga per Kilo', '0.1', 'Masih', '2021-02-09'),
('KT001-4', 'KT001', 'Ikan Asin Sepat', 8000, './images/produk/KT001-4.jpg', 'Harga per Kilo\r\n', '0.1', 'Masih', '2021-02-09'),
('KT001-5', 'KT001', 'Sepat Super', 12000, './images/produk/KT001-5.jpg', 'Harga per Kilo', '0.1', 'Masih', '2021-02-09'),
('KT001-6', 'KT001', 'Layur', 3500, './images/produk/KT001-6.jpg', 'Harga per Kilo', '0.1', 'Masih', '2021-02-09'),
('KT001-7', 'KT001', 'Petek', 3000, './images/produk/KT001-7.jpeg', 'Harga per Kilo', '0.2', 'Masih', '2021-02-09'),
('KT001-8', 'KT001', 'Tamban', 4000, './images/produk/KT001-8.jpeg', 'Harga per Kilo', '0.1', 'Masih', '2021-02-09'),
('KT001-9', 'KT001', 'Tenggiri', 10000, './images/produk/KT001-9.jpg', 'Harga per Kilo', '0.1', 'Masih', '2021-02-09');

-- --------------------------------------------------------

--
-- Table structure for table `t_profil`
--

CREATE TABLE IF NOT EXISTS `t_profil` (
`id_profil` int(3) NOT NULL,
  `nama_toko` varchar(50) NOT NULL,
  `kota_toko` varchar(50) NOT NULL,
  `provinsi_toko` varchar(50) NOT NULL,
  `alamat_toko` varchar(300) NOT NULL,
  `kode_pos` int(10) DEFAULT NULL,
  `tentang_toko` longtext NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `t_profil`
--

INSERT INTO `t_profil` (`id_profil`, `nama_toko`, `kota_toko`, `provinsi_toko`, `alamat_toko`, `kode_pos`, `tentang_toko`) VALUES
(1, 'Ikan Asin', 'Tiku Selatan', 'Sumatera Barat', 'Jalan Jalan', 11111, '<p>Selamat Datang di E-Commerce Ikan Asin<br />\r\n&nbsp;</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `t_rekening`
--

CREATE TABLE IF NOT EXISTS `t_rekening` (
`id_rekening` int(5) NOT NULL,
  `nama_pemilik` varchar(100) NOT NULL,
  `no_rekening` varchar(100) NOT NULL,
  `nama_bank` varchar(100) NOT NULL,
  `cabang` varchar(100) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `t_rekening`
--

INSERT INTO `t_rekening` (`id_rekening`, `nama_pemilik`, `no_rekening`, `nama_bank`, `cabang`) VALUES
(9, 'Ermanto', '543701010086533', 'BRI', 'Tiku Selatan');

-- --------------------------------------------------------

--
-- Table structure for table `t_shipping`
--

CREATE TABLE IF NOT EXISTS `t_shipping` (
`id_shipping` int(5) NOT NULL,
  `wilayah` varchar(50) NOT NULL,
  `int` varchar(50) NOT NULL,
  `kurir` varchar(50) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `t_shipping`
--

INSERT INTO `t_shipping` (`id_shipping`, `wilayah`, `int`, `kurir`) VALUES
(15, 'Padang', '30000', 'JNE'),
(16, 'Lubuk Alung', '10000', 'JNE'),
(17, 'Bukittinggi', '15000', 'JNE'),
(18, 'Pesisir', '40000', 'JNE'),
(19, 'Payakumbuh', '40000', 'JNE');

-- --------------------------------------------------------

--
-- Table structure for table `t_statistika`
--

CREATE TABLE IF NOT EXISTS `t_statistika` (
`id_statistika` int(5) NOT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `hits` int(11) DEFAULT NULL,
  `online` varchar(255) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=52 ;

--
-- Dumping data for table `t_statistika`
--

INSERT INTO `t_statistika` (`id_statistika`, `ip`, `tanggal`, `hits`, `online`) VALUES
(26, '192.168.137.226', '2014-08-02', 1, '1406944271'),
(27, '127.0.0.1', '2014-08-05', 1, '1407237657'),
(28, '127.0.0.1', '2014-08-06', 2, '1407335436'),
(29, '127.0.0.1', '2014-08-07', 1, '1407361423'),
(30, '127.0.0.1', '2014-08-09', 1, '1407588987'),
(31, '127.0.0.1', '2014-08-12', 82, '1407851524'),
(32, '127.0.0.1', '2014-08-13', 2, '1407894910'),
(33, '192.168.96.50', '2014-08-13', 1, '1407897123'),
(34, '::1', '2014-08-14', 4, '1408024915'),
(35, '192.168.88.101', '2014-08-14', 2, '1408024923'),
(36, '127.0.0.1', '2014-08-17', 102, '1408282253'),
(37, '::1', '2014-08-17', 27, '1408280225'),
(38, '192.168.88.63', '2014-08-18', 108, '1408335053'),
(39, '::1', '2014-08-18', 12, '1408340654'),
(40, '::1', '2014-08-27', 16, '1409119361'),
(41, '127.0.0.1', '2014-08-27', 33, '1409118835'),
(42, '10.0.1.51', '2014-08-27', 47, '1409118881'),
(43, '10.0.1.54', '2014-08-27', 52, '1409119160'),
(44, '::1', '2014-09-03', 15, '1409725460'),
(45, '::1', '2014-09-05', 1, '1409881667'),
(46, '::1', '2014-09-06', 2, '1409989103'),
(47, '::1', '2017-08-05', 49, '1501947538'),
(48, '::1', '2021-02-06', 59, '1612630794'),
(49, '::1', '2021-02-07', 428, '1612709745'),
(50, '::1', '2021-02-08', 15, '1612795590'),
(51, '::1', '2021-02-09', 100, '1612884487');

-- --------------------------------------------------------

--
-- Table structure for table `t_tagihan`
--

CREATE TABLE IF NOT EXISTS `t_tagihan` (
`id_tagihan` int(10) NOT NULL,
  `id_member` int(10) NOT NULL,
  `tgl_tagihan` date NOT NULL,
  `total_tagihan` int(50) NOT NULL,
  `foto_faktur` varchar(100) NOT NULL,
  `status_tagihan` enum('Belum Lunas','Lunas') NOT NULL DEFAULT 'Belum Lunas',
  `no_resi` varchar(100) NOT NULL,
  `kurir` varchar(100) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `t_tagihan`
--

INSERT INTO `t_tagihan` (`id_tagihan`, `id_member`, `tgl_tagihan`, `total_tagihan`, `foto_faktur`, `status_tagihan`, `no_resi`, `kurir`) VALUES
(1, 3, '2021-02-07', 70000, './images/konfirmasi/1.jpg', 'Lunas', '', ''),
(2, 3, '2021-02-07', 75000, './images/konfirmasi/2.jpg', 'Lunas', '', ''),
(3, 3, '2021-02-09', 33500, './images/konfirmasi/3.jpg', 'Belum Lunas', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `t_templates`
--

CREATE TABLE IF NOT EXISTS `t_templates` (
`id_template` int(5) NOT NULL,
  `nama_template` varchar(30) NOT NULL,
  `lokasi_template` varchar(100) NOT NULL,
  `aktif_template` enum('0','1') NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `t_templates`
--

INSERT INTO `t_templates` (`id_template`, `nama_template`, `lokasi_template`, `aktif_template`) VALUES
(1, 'Blue', 'blue/', '1');

-- --------------------------------------------------------

--
-- Table structure for table `t_testimonial`
--

CREATE TABLE IF NOT EXISTS `t_testimonial` (
`id_testimonial` int(5) NOT NULL,
  `id_member` int(10) NOT NULL,
  `isi_testimonial` varchar(100) NOT NULL,
  `tgl_testimonial` date NOT NULL,
  `tampil` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `t_testimonial`
--

INSERT INTO `t_testimonial` (`id_testimonial`, `id_member`, `isi_testimonial`, `tgl_testimonial`, `tampil`) VALUES
(8, 3, 'aku suka', '2021-02-07', 1),
(9, 3, 'bagus', '2021-02-07', 1);

-- --------------------------------------------------------

--
-- Table structure for table `t_user`
--

CREATE TABLE IF NOT EXISTS `t_user` (
`id_user` int(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(40) NOT NULL,
  `email` varchar(100) NOT NULL,
  `level` enum('super admin','admin') NOT NULL,
  `last_login` varchar(40) NOT NULL,
  `ip_login` varchar(40) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `t_user`
--

INSERT INTO `t_user` (`id_user`, `username`, `password`, `email`, `level`, `last_login`, `ip_login`) VALUES
(2, 'admin', '771b40499df3ec93265589517f8486bb', 'admin@admin.com', 'admin', '09-02-2021 22:31', '::1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `t_kategori`
--
ALTER TABLE `t_kategori`
 ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `t_keranjang`
--
ALTER TABLE `t_keranjang`
 ADD PRIMARY KEY (`id_keranjang`), ADD KEY `id_produk` (`id_produk`), ADD KEY `id_member` (`id_member`);

--
-- Indexes for table `t_member`
--
ALTER TABLE `t_member`
 ADD PRIMARY KEY (`id_member`);

--
-- Indexes for table `t_order`
--
ALTER TABLE `t_order`
 ADD PRIMARY KEY (`id_order`), ADD KEY `t_order_ibfk_2` (`id_member`), ADD KEY `t_order_ibfk_3` (`id_produk`), ADD KEY `t_order_ibfk_4` (`id_tagihan`);

--
-- Indexes for table `t_pengaturan`
--
ALTER TABLE `t_pengaturan`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_pesan`
--
ALTER TABLE `t_pesan`
 ADD PRIMARY KEY (`id_pesan`);

--
-- Indexes for table `t_produk`
--
ALTER TABLE `t_produk`
 ADD PRIMARY KEY (`id_produk`), ADD KEY `id_kategori` (`id_kategori`);

--
-- Indexes for table `t_profil`
--
ALTER TABLE `t_profil`
 ADD PRIMARY KEY (`id_profil`);

--
-- Indexes for table `t_rekening`
--
ALTER TABLE `t_rekening`
 ADD PRIMARY KEY (`id_rekening`);

--
-- Indexes for table `t_shipping`
--
ALTER TABLE `t_shipping`
 ADD PRIMARY KEY (`id_shipping`);

--
-- Indexes for table `t_statistika`
--
ALTER TABLE `t_statistika`
 ADD PRIMARY KEY (`id_statistika`);

--
-- Indexes for table `t_tagihan`
--
ALTER TABLE `t_tagihan`
 ADD PRIMARY KEY (`id_tagihan`), ADD KEY `t_tagihan_ibfk_2` (`id_member`);

--
-- Indexes for table `t_templates`
--
ALTER TABLE `t_templates`
 ADD PRIMARY KEY (`id_template`);

--
-- Indexes for table `t_testimonial`
--
ALTER TABLE `t_testimonial`
 ADD PRIMARY KEY (`id_testimonial`), ADD KEY `id_member` (`id_member`);

--
-- Indexes for table `t_user`
--
ALTER TABLE `t_user`
 ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `t_keranjang`
--
ALTER TABLE `t_keranjang`
MODIFY `id_keranjang` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `t_member`
--
ALTER TABLE `t_member`
MODIFY `id_member` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `t_order`
--
ALTER TABLE `t_order`
MODIFY `id_order` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `t_pesan`
--
ALTER TABLE `t_pesan`
MODIFY `id_pesan` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `t_profil`
--
ALTER TABLE `t_profil`
MODIFY `id_profil` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `t_rekening`
--
ALTER TABLE `t_rekening`
MODIFY `id_rekening` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `t_shipping`
--
ALTER TABLE `t_shipping`
MODIFY `id_shipping` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `t_statistika`
--
ALTER TABLE `t_statistika`
MODIFY `id_statistika` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=52;
--
-- AUTO_INCREMENT for table `t_tagihan`
--
ALTER TABLE `t_tagihan`
MODIFY `id_tagihan` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `t_templates`
--
ALTER TABLE `t_templates`
MODIFY `id_template` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `t_testimonial`
--
ALTER TABLE `t_testimonial`
MODIFY `id_testimonial` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `t_user`
--
ALTER TABLE `t_user`
MODIFY `id_user` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `t_keranjang`
--
ALTER TABLE `t_keranjang`
ADD CONSTRAINT `t_keranjang_ibfk_1` FOREIGN KEY (`id_produk`) REFERENCES `t_produk` (`id_produk`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `t_keranjang_ibfk_2` FOREIGN KEY (`id_member`) REFERENCES `t_member` (`id_member`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `t_order`
--
ALTER TABLE `t_order`
ADD CONSTRAINT `t_order_ibfk_2` FOREIGN KEY (`id_member`) REFERENCES `t_member` (`id_member`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `t_order_ibfk_3` FOREIGN KEY (`id_produk`) REFERENCES `t_produk` (`id_produk`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `t_order_ibfk_4` FOREIGN KEY (`id_tagihan`) REFERENCES `t_tagihan` (`id_tagihan`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `t_produk`
--
ALTER TABLE `t_produk`
ADD CONSTRAINT `t_produk_ibfk_1` FOREIGN KEY (`id_kategori`) REFERENCES `t_kategori` (`id_kategori`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `t_tagihan`
--
ALTER TABLE `t_tagihan`
ADD CONSTRAINT `t_tagihan_ibfk_1` FOREIGN KEY (`id_member`) REFERENCES `t_member` (`id_member`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `t_testimonial`
--
ALTER TABLE `t_testimonial`
ADD CONSTRAINT `t_testimonial_ibfk_1` FOREIGN KEY (`id_member`) REFERENCES `t_member` (`id_member`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
